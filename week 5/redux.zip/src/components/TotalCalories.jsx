const TotalCalories = () => {
  return <div className="display-5 text-center">Total Calories</div>;
};
export default TotalCalories;
